﻿CREATE TABLE [dbo].[Artist] (
    [ArtistID]   INT            IDENTITY (1, 1) NOT NULL,
    [ArtistName] NVARCHAR (200) NULL,
	PRIMARY KEY CLUSTERED ([ArtistID] ASC)

);


