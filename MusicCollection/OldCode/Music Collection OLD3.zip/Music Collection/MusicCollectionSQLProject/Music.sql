﻿CREATE TABLE [dbo].[Music] (
    [MusicID]       INT            IDENTITY (1, 1) NOT NULL,
    [ArtistID]      INT            NULL,
    [MusicName]     VARCHAR (255)  NULL,
    [GenreID]       INT            NULL,
    [YearOfRelease] INT            NULL,
    [InTheCloud]    BIT            NULL,
    [PhysicalCopy]  BIT            NULL,
    [ArtworkUrl]    NVARCHAR (255) NULL,
    [Notes]         TEXT           NULL,
	PRIMARY KEY CLUSTERED ([MusicID] ASC),
    CONSTRAINT [FK_dbo.Music_dbo.Genre_GenreID] FOREIGN KEY ([GenreID]) 
        REFERENCES [dbo].[Genre] ([GenreID]) ON DELETE CASCADE,
    CONSTRAINT [FK_dbo.Music_dbo.Artist_ArtistID] FOREIGN KEY ([ArtistID]) 
        REFERENCES [dbo].[Artist] ([ArtistID]) ON DELETE CASCADE

);
