﻿CREATE TABLE [dbo].[Genre] (
    [GenreID]          INT         IDENTITY (1, 1) NOT NULL,
    [GenreName]        NCHAR (100) NULL,
    [GenreDescription] TEXT        NULL,
	PRIMARY KEY CLUSTERED ([GenreID] ASC)


);