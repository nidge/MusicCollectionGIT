﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Music_Collection.Models
{
    public class ArtistMetadata
    {
        [StringLength(150)]
        [Display(Name = "Artist Name")]
        public string ArtistName;
    }

    public class MusicMetadata
    {
        [Display(Name = "Album name")]
        public string MusicName;
    }

}