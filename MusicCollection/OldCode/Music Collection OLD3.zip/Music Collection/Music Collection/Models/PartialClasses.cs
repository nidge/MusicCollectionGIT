﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Music_Collection.Models
{
    [MetadataType(typeof(ArtistMetadata))]
    public partial class Artist
    {
    }

    [MetadataType(typeof (MusicMetadata))]
    public partial class Music
    {
    }
}