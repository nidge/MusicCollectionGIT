﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Music_Collection.Startup))]
namespace Music_Collection
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
