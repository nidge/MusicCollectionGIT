﻿CREATE TABLE [dbo].[Track] (
    [TrackID]      INT           IDENTITY (1, 1) NOT NULL,
    [Title]       NVARCHAR (500) NOT NULL,
    [AlbumID]     INT NOT NULL,
 [Sequence]     INT CONSTRAINT DF_Sequence DEFAULT 0,
 [FileName]     NVARCHAR (1000) NULL,
    [Notes]       NVARCHAR (1000) NULL,
    PRIMARY KEY CLUSTERED ([TrackID] ASC),
 CONSTRAINT [FK_dbo.Music_dbo.Album_AlbumID] FOREIGN KEY ([AlbumID]) 
        REFERENCES [dbo].[Album] ([AlbumID]) ON DELETE CASCADE 
)