﻿CREATE TABLE [dbo].[Genre] (
    [GenreID] INT           IDENTITY (1, 1) NOT NULL,
    [Title]    NVARCHAR (200) NOT NULL,
 [Notes]    NVARCHAR (1000) NULL,
    PRIMARY KEY CLUSTERED ([GenreID] ASC),
 CONSTRAINT [IX_Genre_Title] UNIQUE ([Title])
)
