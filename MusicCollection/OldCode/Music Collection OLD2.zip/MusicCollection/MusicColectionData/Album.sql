﻿CREATE TABLE [dbo].[Album] (
    [AlbumID]      INT           IDENTITY (1, 1) NOT NULL,
    [Title]       NVARCHAR (500) NOT NULL,
    [ArtistID]     INT NOT NULL,
 [GenreID]     INT,
 [InCloud]     bit  CONSTRAINT DF_InCloud DEFAULT 0,
    [Notes]       NVARCHAR (1000) NULL,
 [PictureUrl]       NVARCHAR (1000),
    PRIMARY KEY CLUSTERED ([AlbumID] ASC),
 CONSTRAINT [FK_dbo.Music_dbo.Artist_ArtistID] FOREIGN KEY ([ArtistID]) 
        REFERENCES [dbo].[Artist] ([ArtistID]) ON DELETE CASCADE,
  
 CONSTRAINT [FK_dbo.Music_dbo.Genre_GenreID] FOREIGN KEY ([GenreID]) 
        REFERENCES [dbo].[Genre] ([GenreID]) ON DELETE CASCADE
)

