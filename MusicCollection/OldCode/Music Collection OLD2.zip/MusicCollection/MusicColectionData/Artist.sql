﻿CREATE TABLE [dbo].[Artist] (
    [ArtistID] INT           IDENTITY (1, 1) NOT NULL,
    [Title]    NVARCHAR (200) NOT NULL,
 [Notes]    NVARCHAR (1000) NULL,
    PRIMARY KEY CLUSTERED ([ArtistID] ASC),
 CONSTRAINT [IX_Artist_Title] UNIQUE ([Title])
)
