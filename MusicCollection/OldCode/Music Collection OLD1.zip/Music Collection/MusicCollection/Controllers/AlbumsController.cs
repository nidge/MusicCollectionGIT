﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MusicCollection.Models;

namespace MusicCollection.Controllers
{
    public class AlbumsController : Controller
    {
        private MusicCollectionDBEntities db = new MusicCollectionDBEntities();

        // GET: Albums
        public ActionResult Index()
        {
            var tblAlbums = db.tblAlbums.Include(t => t.tblArtist).Include(t => t.tblGenre);
            return View(tblAlbums.ToList());
        }

        // GET: Albums/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblAlbum tblAlbum = db.tblAlbums.Find(id);
            if (tblAlbum == null)
            {
                return HttpNotFound();
            }
            return View(tblAlbum);
        }

        // GET: Albums/Create
        public ActionResult Create()
        {
            ViewBag.ArtistID = new SelectList(db.tblArtists, "ID", "Artist");
            ViewBag.GenreID = new SelectList(db.tblGenres, "GenreID", "GenreName");
            return View();
        }

        // POST: Albums/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "AlbumID,ArtistID,ArtistName,AlbumName,YearOfRelease,InTheCloud,PhysicalCopy,GenreID")] tblAlbum tblAlbum)
        {
            if (ModelState.IsValid)
            {
                db.tblAlbums.Add(tblAlbum);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ArtistID = new SelectList(db.tblArtists, "ID", "Artist", tblAlbum.ArtistID);
            ViewBag.GenreID = new SelectList(db.tblGenres, "GenreID", "GenreName", tblAlbum.GenreID);
            return View(tblAlbum);
        }

        // GET: Albums/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblAlbum tblAlbum = db.tblAlbums.Find(id);
            if (tblAlbum == null)
            {
                return HttpNotFound();
            }
            ViewBag.ArtistID = new SelectList(db.tblArtists, "ID", "Artist", tblAlbum.ArtistID);
            ViewBag.GenreID = new SelectList(db.tblGenres, "GenreID", "GenreName", tblAlbum.GenreID);
            return View(tblAlbum);
        }

        // POST: Albums/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "AlbumID,ArtistID,ArtistName,AlbumName,YearOfRelease,InTheCloud,PhysicalCopy,GenreID")] tblAlbum tblAlbum)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tblAlbum).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ArtistID = new SelectList(db.tblArtists, "ID", "Artist", tblAlbum.ArtistID);
            ViewBag.GenreID = new SelectList(db.tblGenres, "GenreID", "GenreName", tblAlbum.GenreID);
            return View(tblAlbum);
        }

        // GET: Albums/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblAlbum tblAlbum = db.tblAlbums.Find(id);
            if (tblAlbum == null)
            {
                return HttpNotFound();
            }
            return View(tblAlbum);
        }

        // POST: Albums/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tblAlbum tblAlbum = db.tblAlbums.Find(id);
            db.tblAlbums.Remove(tblAlbum);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
