﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(MusicCollection2016Web.Startup))]
namespace MusicCollection2016Web
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
